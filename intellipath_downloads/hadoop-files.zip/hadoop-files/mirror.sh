#!/bin/sh
sudo cp -pr /etc/yum.repos.d/CentOS-Base.repo /etc/yum.repos.d/CentOS-Base.repo.OLD
sudo rm /etc/yum.repos.d/CentOS-Base.repo
sudo cp CentOS-Base.repo /etc/yum.repos.d/CentOS-Base.repo
